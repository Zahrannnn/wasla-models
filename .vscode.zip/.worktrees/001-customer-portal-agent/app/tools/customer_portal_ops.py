"""
Customer portal tool operations.

These are public (no auth required) tools for company discovery.
"""

from __future__ import annotations

from typing import Any

import logging
import time

from app.services import crm_client

logger = logging.getLogger("wasla.tools.customer_portal")


async def search_companies(
    bearer_token: str | None,
    *,
    mode: str,
    service_type: str | None = None,
    search: str | None = None,
    sort_by: str | None = None,
    page_index: int | None = None,
    page_size: int | None = None,
) -> dict[str, Any]:
    del bearer_token
    start = time.perf_counter()
    mode_normalized = mode.strip().lower()
    if mode_normalized == "list":
        result = await crm_client.list_companies(
            page_index=page_index,
            page_size=page_size,
            search=search,
            service_type=service_type,
            sort_by=sort_by,
        )
        logger.info("search_companies", extra={"mode": mode_normalized, "elapsed_ms": int((time.perf_counter() - start) * 1000), "status": result.get("status") or result.get("error")})
        return result
    if mode_normalized == "recommended":
        result = await crm_client.get_recommended_companies(
            page_index=page_index,
            page_size=page_size,
            service_type=service_type,
        )
        logger.info("search_companies", extra={"mode": mode_normalized, "elapsed_ms": int((time.perf_counter() - start) * 1000), "status": result.get("status") or result.get("error")})
        return result
    if mode_normalized == "trending":
        result = await crm_client.get_trending_companies(
            page_index=page_index,
            page_size=page_size,
            service_type=service_type,
        )
        logger.info("search_companies", extra={"mode": mode_normalized, "elapsed_ms": int((time.perf_counter() - start) * 1000), "status": result.get("status") or result.get("error")})
        return result
    result = {"error": "bad_request", "message": "Invalid mode. Use list, recommended, or trending."}
    logger.info("search_companies", extra={"mode": mode_normalized, "elapsed_ms": int((time.perf_counter() - start) * 1000), "status": result.get("error")})
    return result


async def get_company_profile(
    bearer_token: str | None,
    *,
    company_id: int,
) -> dict[str, Any]:
    del bearer_token
    start = time.perf_counter()
    result = await crm_client.get_company_profile(company_id)
    logger.info("get_company_profile", extra={"company_id": company_id, "elapsed_ms": int((time.perf_counter() - start) * 1000), "status": result.get("status") or result.get("error")})
    return result


async def get_company_reviews(
    bearer_token: str | None,
    *,
    company_id: int,
    sort_by: str | None = None,
    page_index: int | None = None,
    page_size: int | None = None,
) -> dict[str, Any]:
    del bearer_token
    start = time.perf_counter()
    result = await crm_client.get_company_reviews(
        company_id,
        page_index=page_index,
        page_size=page_size,
        sort_by=sort_by,
    )
    logger.info("get_company_reviews", extra={"company_id": company_id, "elapsed_ms": int((time.perf_counter() - start) * 1000), "status": result.get("status") or result.get("error")})
    return result


async def submit_service_request(
    bearer_token: str | None,
    *,
    company_id: int,
    preferred_date: str | None = None,
    origin_address: str | None = None,
    destination_address: str | None = None,
    notes: str | None = None,
) -> dict[str, Any]:
    if not bearer_token:
        return {"error": "unauthorized", "message": "Authentication required."}
    start = time.perf_counter()
    result = await crm_client.submit_service_request(
        bearer_token,
        company_id=company_id,
        preferred_date=preferred_date,
        origin_address=origin_address,
        destination_address=destination_address,
        notes=notes,
    )
    logger.info("submit_service_request", extra={"company_id": company_id, "elapsed_ms": int((time.perf_counter() - start) * 1000), "status": result.get("status") or result.get("error")})
    return result


async def get_my_service_requests(
    bearer_token: str | None,
    *,
    request_id: int | None = None,
    status: str | None = None,
    page_index: int | None = None,
    page_size: int | None = None,
) -> dict[str, Any]:
    if not bearer_token:
        return {"error": "unauthorized", "message": "Authentication required."}
    if request_id is not None:
        start = time.perf_counter()
        result = await crm_client.get_service_request_details(bearer_token, request_id)
        logger.info("get_my_service_requests", extra={"request_id": request_id, "elapsed_ms": int((time.perf_counter() - start) * 1000), "status": result.get("status") or result.get("error")})
        return result
    start = time.perf_counter()
    result = await crm_client.get_my_service_requests(
        bearer_token,
        page_index=page_index,
        page_size=page_size,
        status=status,
    )
    logger.info("get_my_service_requests", extra={"elapsed_ms": int((time.perf_counter() - start) * 1000), "status": result.get("status") or result.get("error")})
    return result


async def get_my_offers(
    bearer_token: str | None,
    *,
    offer_id: int | None = None,
    status: str | None = None,
    page_index: int | None = None,
    page_size: int | None = None,
) -> dict[str, Any]:
    if not bearer_token:
        return {"error": "unauthorized", "message": "Authentication required."}
    if offer_id is not None:
        start = time.perf_counter()
        result = await crm_client.get_offer_details(bearer_token, offer_id)
        logger.info("get_my_offers", extra={"offer_id": offer_id, "elapsed_ms": int((time.perf_counter() - start) * 1000), "status": result.get("status") or result.get("error")})
        return result
    start = time.perf_counter()
    result = await crm_client.get_my_offers(
        bearer_token,
        page_index=page_index,
        page_size=page_size,
        status=status,
    )
    logger.info("get_my_offers", extra={"elapsed_ms": int((time.perf_counter() - start) * 1000), "status": result.get("status") or result.get("error")})
    return result


async def accept_offer(
    bearer_token: str | None,
    *,
    offer_id: int,
    digital_signature: str,
    payment_method: int,
) -> dict[str, Any]:
    if not bearer_token:
        return {"error": "unauthorized", "message": "Authentication required."}
    start = time.perf_counter()
    result = await crm_client.accept_offer(
        bearer_token,
        offer_id,
        digital_signature=digital_signature,
        payment_method=payment_method,
    )
    logger.info("accept_offer", extra={"offer_id": offer_id, "elapsed_ms": int((time.perf_counter() - start) * 1000), "status": result.get("status") or result.get("error")})
    return result


async def reject_offer(
    bearer_token: str | None,
    *,
    offer_id: int,
    rejection_reason: str,
) -> dict[str, Any]:
    if not bearer_token:
        return {"error": "unauthorized", "message": "Authentication required."}
    start = time.perf_counter()
    result = await crm_client.reject_offer(
        bearer_token,
        offer_id,
        rejection_reason=rejection_reason,
    )
    logger.info("reject_offer", extra={"offer_id": offer_id, "elapsed_ms": int((time.perf_counter() - start) * 1000), "status": result.get("status") or result.get("error")})
    return result


async def manage_review(
    bearer_token: str | None,
    *,
    action: str,
    company_id: int | None = None,
    rating: int | None = None,
    review_text: str | None = None,
    page_index: int | None = None,
    page_size: int | None = None,
) -> dict[str, Any]:
    if not bearer_token:
        return {"error": "unauthorized", "message": "Authentication required."}

    normalized = action.strip().lower()
    if normalized == "list_mine":
        start = time.perf_counter()
        result = await crm_client.get_my_reviews(
            bearer_token,
            page_index=page_index,
            page_size=page_size,
        )
        logger.info("manage_review", extra={"action": normalized, "elapsed_ms": int((time.perf_counter() - start) * 1000), "status": result.get("status") or result.get("error")})
        return result

    if company_id is None:
        return {"error": "bad_request", "message": "company_id is required for this action."}

    if normalized == "submit":
        if rating is None:
            return {"error": "bad_request", "message": "rating is required to submit a review."}
        start = time.perf_counter()
        result = await crm_client.submit_review(
            bearer_token,
            company_id,
            rating=rating,
            review_text=review_text,
        )
        logger.info("manage_review", extra={"action": normalized, "company_id": company_id, "elapsed_ms": int((time.perf_counter() - start) * 1000), "status": result.get("status") or result.get("error")})
        return result

    if normalized == "update":
        if rating is None and review_text is None:
            return {"error": "bad_request", "message": "rating or review_text is required to update a review."}
        start = time.perf_counter()
        result = await crm_client.update_review(
            bearer_token,
            company_id,
            rating=rating,
            review_text=review_text,
        )
        logger.info("manage_review", extra={"action": normalized, "company_id": company_id, "elapsed_ms": int((time.perf_counter() - start) * 1000), "status": result.get("status") or result.get("error")})
        return result

    if normalized == "delete":
        start = time.perf_counter()
        result = await crm_client.delete_review(bearer_token, company_id)
        logger.info("manage_review", extra={"action": normalized, "company_id": company_id, "elapsed_ms": int((time.perf_counter() - start) * 1000), "status": result.get("status") or result.get("error")})
        return result

    return {"error": "bad_request", "message": "Invalid action. Use submit, update, delete, or list_mine."}


async def get_my_profile(
    bearer_token: str | None,
    *,
    profile_type: str,
) -> dict[str, Any]:
    if not bearer_token:
        return {"error": "unauthorized", "message": "Authentication required."}
    normalized = profile_type.strip().lower()
    if normalized == "customer":
        start = time.perf_counter()
        result = await crm_client.get_my_profile(bearer_token)
        logger.info("get_my_profile", extra={"profile_type": normalized, "elapsed_ms": int((time.perf_counter() - start) * 1000), "status": result.get("status") or result.get("error")})
        return result
    if normalized == "lead":
        start = time.perf_counter()
        result = await crm_client.get_my_lead_profile(bearer_token)
        logger.info("get_my_profile", extra={"profile_type": normalized, "elapsed_ms": int((time.perf_counter() - start) * 1000), "status": result.get("status") or result.get("error")})
        return result
    return {"error": "bad_request", "message": "Invalid profile_type. Use customer or lead."}


async def update_my_profile(
    bearer_token: str | None,
    *,
    profile_type: str,
    first_name: str | None = None,
    last_name: str | None = None,
    email: str | None = None,
    phone_number: str | None = None,
    address: str | None = None,
    city: str | None = None,
    zip_code: str | None = None,
    country: str | None = None,
) -> dict[str, Any]:
    if not bearer_token:
        return {"error": "unauthorized", "message": "Authentication required."}
    payload = {
        "firstName": first_name,
        "lastName": last_name,
        "email": email,
        "phoneNumber": phone_number,
        "address": address,
        "city": city,
        "zipCode": zip_code,
        "country": country,
    }
    payload = {k: v for k, v in payload.items() if v is not None}
    normalized = profile_type.strip().lower()
    if normalized == "customer":
        start = time.perf_counter()
        result = await crm_client.update_my_profile(bearer_token, payload)
        logger.info("update_my_profile", extra={"profile_type": normalized, "elapsed_ms": int((time.perf_counter() - start) * 1000), "status": result.get("status") or result.get("error")})
        return result
    if normalized == "lead":
        start = time.perf_counter()
        result = await crm_client.update_my_lead_profile(bearer_token, payload)
        logger.info("update_my_profile", extra={"profile_type": normalized, "elapsed_ms": int((time.perf_counter() - start) * 1000), "status": result.get("status") or result.get("error")})
        return result
    return {"error": "bad_request", "message": "Invalid profile_type. Use customer or lead."}


async def get_dashboard(
    bearer_token: str | None,
) -> dict[str, Any]:
    if not bearer_token:
        return {"error": "unauthorized", "message": "Authentication required."}
    start = time.perf_counter()
    result = await crm_client.get_my_dashboard(bearer_token)
    logger.info("get_dashboard", extra={"elapsed_ms": int((time.perf_counter() - start) * 1000), "status": result.get("status") or result.get("error")})
    return result
