"""
Tool definitions — JSON schemas for the LLM.

Each entry follows the OpenAI / HF-compatible function-calling format.
Add new tools here and then wire them in ``operations.py`` + ``registry.py``.
"""

from __future__ import annotations

from typing import Any

TOOLS: list[dict[str, Any]] = [
    # ── Read operations ───────────────────────────────────────────
    {
        "type": "function",
        "function": {
            "name": "get_customer_list",
            "description": "Fetches a list of customers for the company.",
            "parameters": {
                "type": "object",
                "properties": {
                    "limit": {
                        "type": "integer",
                        "description": "Maximum number of customers to return.",
                    },
                },
                "required": ["limit"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "get_customer_details",
            "description": "Fetches detailed information about a single customer.",
            "parameters": {
                "type": "object",
                "properties": {
                    "customer_id": {
                        "type": "string",
                        "description": "The unique identifier of the customer.",
                    },
                },
                "required": ["customer_id"],
            },
        },
    },
    # ── Search / Navigate ─────────────────────────────────────────
    {
        "type": "function",
        "function": {
            "name": "search_products",
            "description": "Searches the product catalog by keyword.",
            "parameters": {
                "type": "object",
                "properties": {
                    "query": {
                        "type": "string",
                        "description": "Search keyword or phrase.",
                    },
                    "category": {
                        "type": "string",
                        "description": "Optional product category filter.",
                    },
                },
                "required": ["query"],
            },
        },
    },
    # ── Write operations ──────────────────────────────────────────
    {
        "type": "function",
        "function": {
            "name": "create_order",
            "description": "Creates a new order for a customer.",
            "parameters": {
                "type": "object",
                "properties": {
                    "customer_id": {
                        "type": "string",
                        "description": "The customer placing the order.",
                    },
                    "product_ids": {
                        "type": "array",
                        "items": {"type": "string"},
                        "description": "List of product IDs to include in the order.",
                    },
                },
                "required": ["customer_id", "product_ids"],
            },
        },
    },
]

# ── Customer Portal tools (Customer Portal Agent) ─────────────────
CUSTOMER_PORTAL_TOOLS: list[dict[str, Any]] = [
    {
        "type": "function",
        "function": {
            "name": "search_companies",
            "description": "Search, recommend, or list trending service companies.",
            "parameters": {
                "type": "object",
                "properties": {
                    "mode": {
                        "type": "string",
                        "description": "One of: list, recommended, trending.",
                    },
                    "service_type": {
                        "type": "string",
                        "description": "Filter by service type.",
                    },
                    "search": {
                        "type": "string",
                        "description": "Company name search (list mode only).",
                    },
                    "sort_by": {
                        "type": "string",
                        "description": "Sort by rating or newest (list mode only).",
                    },
                    "page_index": {
                        "type": "integer",
                        "description": "Page number (1-based).",
                    },
                    "page_size": {
                        "type": "integer",
                        "description": "Items per page.",
                    },
                },
                "required": ["mode"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "get_company_profile",
            "description": "Fetch a company's public profile and service catalog.",
            "parameters": {
                "type": "object",
                "properties": {
                    "company_id": {
                        "type": "integer",
                        "description": "Company ID.",
                    },
                },
                "required": ["company_id"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "get_company_reviews",
            "description": "Fetch reviews for a company.",
            "parameters": {
                "type": "object",
                "properties": {
                    "company_id": {
                        "type": "integer",
                        "description": "Company ID.",
                    },
                    "sort_by": {
                        "type": "string",
                        "description": "Sort by newest or highest-rated.",
                    },
                    "page_index": {
                        "type": "integer",
                        "description": "Page number (1-based).",
                    },
                    "page_size": {
                        "type": "integer",
                        "description": "Items per page.",
                    },
                },
                "required": ["company_id"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "submit_service_request",
            "description": "Submit a service request to a company.",
            "parameters": {
                "type": "object",
                "properties": {
                    "company_id": {
                        "type": "integer",
                        "description": "Target company ID.",
                    },
                    "preferred_date": {
                        "type": "string",
                        "description": "Preferred service date (ISO 8601).",
                    },
                    "origin_address": {
                        "type": "string",
                        "description": "Pickup address.",
                    },
                    "destination_address": {
                        "type": "string",
                        "description": "Delivery address.",
                    },
                    "notes": {
                        "type": "string",
                        "description": "Additional notes.",
                    },
                },
                "required": ["company_id"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "get_my_service_requests",
            "description": "List or fetch service requests for the authenticated customer.",
            "parameters": {
                "type": "object",
                "properties": {
                    "request_id": {
                        "type": "integer",
                        "description": "Specific request ID (omit for list).",
                    },
                    "status": {
                        "type": "string",
                        "description": "Filter by status.",
                    },
                    "page_index": {
                        "type": "integer",
                        "description": "Page number (1-based).",
                    },
                    "page_size": {
                        "type": "integer",
                        "description": "Items per page.",
                    },
                },
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "get_my_offers",
            "description": "List offers or fetch a specific offer for the authenticated customer.",
            "parameters": {
                "type": "object",
                "properties": {
                    "offer_id": {
                        "type": "integer",
                        "description": "Specific offer ID (omit for list).",
                    },
                    "status": {
                        "type": "string",
                        "description": "Filter by status.",
                    },
                    "page_index": {
                        "type": "integer",
                        "description": "Page number (1-based).",
                    },
                    "page_size": {
                        "type": "integer",
                        "description": "Items per page.",
                    },
                },
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "accept_offer",
            "description": "Accept an offer with digital signature and payment method.",
            "parameters": {
                "type": "object",
                "properties": {
                    "offer_id": {
                        "type": "integer",
                        "description": "Offer ID to accept.",
                    },
                    "digital_signature": {
                        "type": "string",
                        "description": "Customer digital signature (SIG-XXXXX-XXXXX).",
                    },
                    "payment_method": {
                        "type": "integer",
                        "description": "Payment method: 0 (COD) or 1 (Online).",
                    },
                },
                "required": ["offer_id", "digital_signature", "payment_method"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "reject_offer",
            "description": "Reject an offer with a reason.",
            "parameters": {
                "type": "object",
                "properties": {
                    "offer_id": {
                        "type": "integer",
                        "description": "Offer ID to reject.",
                    },
                    "rejection_reason": {
                        "type": "string",
                        "description": "Reason for rejection.",
                    },
                },
                "required": ["offer_id", "rejection_reason"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "manage_review",
            "description": "Submit, update, delete, or list the customer's reviews.",
            "parameters": {
                "type": "object",
                "properties": {
                    "action": {
                        "type": "string",
                        "description": "submit, update, delete, or list_mine.",
                    },
                    "company_id": {
                        "type": "integer",
                        "description": "Company ID for submit/update/delete.",
                    },
                    "rating": {
                        "type": "integer",
                        "description": "Rating 1-5 for submit/update.",
                    },
                    "review_text": {
                        "type": "string",
                        "description": "Review text content.",
                    },
                    "page_index": {
                        "type": "integer",
                        "description": "Page number (1-based) for list_mine.",
                    },
                    "page_size": {
                        "type": "integer",
                        "description": "Items per page for list_mine.",
                    },
                },
                "required": ["action"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "get_my_profile",
            "description": "Fetch the customer or lead profile.",
            "parameters": {
                "type": "object",
                "properties": {
                    "profile_type": {
                        "type": "string",
                        "description": "customer or lead.",
                    },
                },
                "required": ["profile_type"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "update_my_profile",
            "description": "Update the customer or lead profile.",
            "parameters": {
                "type": "object",
                "properties": {
                    "profile_type": {
                        "type": "string",
                        "description": "customer or lead.",
                    },
                    "first_name": {
                        "type": "string",
                        "description": "Updated first name.",
                    },
                    "last_name": {
                        "type": "string",
                        "description": "Updated last name.",
                    },
                    "email": {
                        "type": "string",
                        "description": "Updated email address.",
                    },
                    "phone_number": {
                        "type": "string",
                        "description": "Updated phone number.",
                    },
                    "address": {
                        "type": "string",
                        "description": "Updated address.",
                    },
                    "city": {
                        "type": "string",
                        "description": "Updated city.",
                    },
                    "zip_code": {
                        "type": "string",
                        "description": "Updated zip code.",
                    },
                    "country": {
                        "type": "string",
                        "description": "Updated country.",
                    },
                },
                "required": ["profile_type"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "get_dashboard",
            "description": "Fetch dashboard summary metrics for the authenticated customer.",
            "parameters": {
                "type": "object",
                "properties": {},
            },
        },
    },
]


def customer_portal_tools_to_description() -> str:
    """
    Convert customer portal tool definitions to a readable format.

    Returns
    -------
    str
        Formatted tool descriptions for the customer portal system prompt.
    """
    lines = []
    for tool in CUSTOMER_PORTAL_TOOLS:
        func = tool["function"]
        name = func["name"]
        desc = func["description"]

        params = func.get("parameters", {})
        properties = params.get("properties", {})
        required = params.get("required", [])

        param_strs = []
        for param_name, param_info in properties.items():
            param_desc = param_info.get("description", "")
            is_required = param_name in required
            req_marker = " (required)" if is_required else " (optional)"
            param_strs.append(f"    - {param_name}{req_marker}: {param_desc}")

        params_block = "\n".join(param_strs) if param_strs else "    No parameters"
        lines.append(f"- {name}: {desc}\n{params_block}")

    return "\n\n".join(lines)
