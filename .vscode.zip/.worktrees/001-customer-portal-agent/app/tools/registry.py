"""
Tool registry — maps tool JSON names to actual Python functions.

The ``execute_tool`` dispatcher is the single entry-point used by
``llm_service.py`` to run whichever tool the model chose.
"""

from __future__ import annotations

import json
import logging
from typing import Any, Callable, Coroutine

from app.tools import operations
from app.tools import customer_portal_ops

logger = logging.getLogger("wasla.tools")

# ── Name → function mapping ──────────────────────────────────────
_REGISTRY: dict[str, Callable[..., Coroutine]] = {
    "get_customer_list": operations.get_customer_list,
    "get_customer_details": operations.get_customer_details,
    "search_products": operations.search_products,
    "create_order": operations.create_order,
}

# ── Customer Portal tool registry ─────────────────────────────────
_CUSTOMER_PORTAL_REGISTRY: dict[str, Callable[..., Coroutine]] = {
    "search_companies": customer_portal_ops.search_companies,
    "get_company_profile": customer_portal_ops.get_company_profile,
    "get_company_reviews": customer_portal_ops.get_company_reviews,
    "submit_service_request": customer_portal_ops.submit_service_request,
    "get_my_service_requests": customer_portal_ops.get_my_service_requests,
    "get_my_offers": customer_portal_ops.get_my_offers,
    "accept_offer": customer_portal_ops.accept_offer,
    "reject_offer": customer_portal_ops.reject_offer,
    "manage_review": customer_portal_ops.manage_review,
    "get_my_profile": customer_portal_ops.get_my_profile,
    "update_my_profile": customer_portal_ops.update_my_profile,
    "get_dashboard": customer_portal_ops.get_dashboard,
}


async def execute_tool(
    tool_name: str,
    arguments: dict[str, Any] | str,
    company_id: str,
) -> str:
    """
    Look up *tool_name*, call the matching function with
    **arguments, and return the result as a JSON string.

    Parameters
    ----------
    tool_name   : Function name the model chose to invoke.
    arguments   : Parsed dict **or** raw JSON string from the model.
    company_id  : Passed to every tool as positional context.

    Returns
    -------
    A JSON-encoded string suitable for the ``tool`` message role.
    """
    # Parse raw JSON if the model returned a string
    if isinstance(arguments, str):
        try:
            arguments = json.loads(arguments)
        except json.JSONDecodeError:
            return json.dumps({"error": f"Invalid JSON arguments: {arguments}"})

    func = _REGISTRY.get(tool_name)
    if func is None:
        logger.warning("Unknown tool requested: %s", tool_name)
        return json.dumps({"error": f"Unknown tool: {tool_name}"})

    try:
        result = await func(company_id, **arguments)
    except Exception as exc:
        logger.exception("Tool %s raised an error", tool_name)
        result = {"error": str(exc)}

    return json.dumps(result)


async def execute_customer_portal_tool(
    tool_name: str,
    arguments: dict[str, Any] | str,
    bearer_token: str | None,
) -> str:
    """
    Execute a customer portal tool with bearer token context.
    """
    if isinstance(arguments, str):
        try:
            arguments = json.loads(arguments)
        except json.JSONDecodeError:
            return json.dumps({"error": f"Invalid JSON arguments: {arguments}"})

    func = _CUSTOMER_PORTAL_REGISTRY.get(tool_name)
    if func is None:
        logger.warning("Unknown customer portal tool requested: %s", tool_name)
        return json.dumps({"error": f"Unknown tool: {tool_name}"})

    try:
        result = await func(bearer_token, **arguments)
    except Exception as exc:
        logger.exception("Customer portal tool %s raised an error", tool_name)
        result = {"error": str(exc)}

    return json.dumps(result)
