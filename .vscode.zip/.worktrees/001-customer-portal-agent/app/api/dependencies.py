"""
Reusable FastAPI dependencies.

Provides common path-parameter extraction and per-request
rate-limit enforcement so routes stay clean.
"""

from __future__ import annotations

from fastapi import Header, Path

from pydantic import BaseModel, Field

from app.core.rate_limit import check_rate_limit


# ── Request / response models ────────────────────────────────────

class ChatRequest(BaseModel):
    """Body for the main chat endpoint (Route 1)."""

    prompt: str = Field(
        ...,
        min_length=1,
        description="The user's message to the AI assistant.",
        json_schema_extra={"examples": ["Show me the top 5 customers"]},
    )
    conversation_history: list[dict] = Field(
        default_factory=list,
        description=(
            "Previous messages for multi-turn context. "
            "Each dict must have `role` (user/assistant/system) and `content` keys."
        ),
        json_schema_extra={
            "examples": [
                [
                    {"role": "user", "content": "Hello"},
                    {"role": "assistant", "content": "Hi! How can I help you?"},
                ]
            ]
        },
    )

    model_config = {
        "json_schema_extra": {
            "examples": [
                {
                    "prompt": "Show me the top 5 customers",
                    "conversation_history": [],
                },
                {
                    "prompt": "Tell me more about the first one",
                    "conversation_history": [
                        {"role": "user", "content": "Show me the top 5 customers"},
                        {"role": "assistant", "content": "Here are your top 5 customers..."},
                    ],
                },
            ]
        }
    }


class VoiceChatRequest(BaseModel):
    """Body for the voice streaming endpoint (Route 2)."""

    prompt: str = Field(
        ...,
        min_length=1,
        description="Spoken user message (transcribed text).",
        json_schema_extra={"examples": ["What are today's sales?"]},
    )
    conversation_history: list[dict] = Field(
        default_factory=list,
        description="Previous messages for multi-turn context.",
    )

    model_config = {
        "json_schema_extra": {
            "examples": [
                {
                    "prompt": "What are today's sales?",
                    "conversation_history": [],
                }
            ]
        }
    }


class ChatResponse(BaseModel):
    """JSON response from the main chat endpoint."""

    response: str = Field(
        ...,
        description="The AI assistant's response text (may contain Markdown).",
    )
    tool_calls_made: int = Field(
        default=0,
        description="Number of tool calls executed during this request.",
    )
    model_used: str = Field(
        default="",
        description="The HF model that produced the response.",
    )

    model_config = {
        "json_schema_extra": {
            "examples": [
                {
                    "response": "Here are your top 5 customers:\n\n1. Acme Corp — $12,400\n2. ...",
                    "tool_calls_made": 1,
                    "model_used": "meta-llama/Llama-3.3-70B-Instruct",
                }
            ]
        }
    }


class CustomerPortalChatRequest(BaseModel):
    """Body for the customer portal chat endpoints."""

    prompt: str = Field(
        ...,
        min_length=1,
        description="The customer's message to the assistant.",
        json_schema_extra={"examples": ["Show me moving companies in Zurich"]},
    )
    conversation_history: list[dict] = Field(
        default_factory=list,
        description=(
            "Previous messages for multi-turn context. "
            "Each dict must have `role` (user/assistant/system) and `content` keys."
        ),
    )


class TTSRequest(BaseModel):
    """Body for the text-to-speech endpoint (Route 4)."""

    text: str = Field(
        ...,
        min_length=1,
        max_length=1000,
        description="The text to synthesize into speech audio.",
        json_schema_extra={"examples": ["Hello, welcome to Wasla! How can I help you today?"]},
    )

    model_config = {
        "json_schema_extra": {
            "examples": [
                {"text": "Hello, welcome to Wasla! How can I help you today?"}
            ]
        }
    }


# ── Dependency functions ─────────────────────────────────────────

async def get_company_id(
    company_id: str = Path(
        ...,
        description="Tenant / company identifier (e.g. `acme-corp`).",
        examples=["acme-corp", "demo-company"],
    ),
) -> str:
    """Extract and validate the company_id path parameter."""
    return company_id


async def enforce_rate_limit(
    company_id: str = Path(
        ...,
        description="Tenant identifier — used for per-company rate limiting.",
    ),
) -> None:
    """Check the per-company rate limit via Redis (30 req / 60 s by default)."""
    await check_rate_limit(company_id)


async def get_bearer_token(
    authorization: str | None = Header(
        default=None,
        description="Bearer token for customer portal authentication.",
    ),
) -> str | None:
    if not authorization:
        return None
    if authorization.lower().startswith("bearer "):
        return authorization[7:].strip()
    return None


async def enforce_customer_rate_limit(
    bearer_token: str | None = Header(default=None, alias="Authorization"),
) -> None:
    token = None
    if bearer_token and bearer_token.lower().startswith("bearer "):
        token = bearer_token[7:].strip()
    key = f"customer:{token}" if token else "customer:anonymous"
    await check_rate_limit(key)
