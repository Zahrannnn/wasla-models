"""
Customer portal chat routes.

POST /api/customer-portal/chat         → tool-calling loop
POST /api/customer-portal/chat/stream  → SSE token stream
"""

from __future__ import annotations

import logging

from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import StreamingResponse

from app.api.dependencies import (
    ChatResponse,
    CustomerPortalChatRequest,
    enforce_customer_rate_limit,
    get_bearer_token,
)
from app.prompts.customer_portal_prompt import get_customer_portal_system_prompt
from app.services.llm_service import customer_portal_chat_with_tools, stream_chat
from app.tools.schemas import customer_portal_tools_to_description

logger = logging.getLogger("wasla.routes.customer_portal")
router = APIRouter(tags=["Customer Portal"])


@router.post(
    "/api/customer-portal/chat",
    response_model=ChatResponse,
    dependencies=[Depends(enforce_customer_rate_limit)],
    summary="Customer portal chat with tool calling",
    operation_id="customerPortalChat",
)
async def customer_portal_chat(
    body: CustomerPortalChatRequest,
    bearer_token: str | None = Depends(get_bearer_token),
):
    tools_description = customer_portal_tools_to_description()
    system_prompt = get_customer_portal_system_prompt(tools_description)
    messages = [{"role": "system", "content": system_prompt}]

    if body.conversation_history:
        messages.extend(body.conversation_history)

    messages.append({"role": "user", "content": body.prompt})

    try:
        result = await customer_portal_chat_with_tools(bearer_token, messages)
    except Exception as exc:
        logger.exception("Customer portal chat failed")
        raise HTTPException(
            status_code=503,
            detail="AI model is unavailable. Please try again later.",
        ) from exc

    return ChatResponse(**result)


@router.post(
    "/api/customer-portal/chat/stream",
    dependencies=[Depends(enforce_customer_rate_limit)],
    summary="Customer portal chat token stream (SSE)",
    operation_id="customerPortalChatStream",
)
async def customer_portal_chat_stream(body: CustomerPortalChatRequest):
    system_prompt = get_customer_portal_system_prompt(
        "No tools available. Provide helpful responses without calling tools."
    )
    messages = [{"role": "system", "content": system_prompt}]

    if body.conversation_history:
        messages.extend(body.conversation_history)

    messages.append({"role": "user", "content": body.prompt})

    return StreamingResponse(
        stream_chat(messages),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
            "X-Accel-Buffering": "no",
        },
    )
