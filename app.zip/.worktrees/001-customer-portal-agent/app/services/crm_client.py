"""
Async CRM client for Wasla Customer Portal API.

Uses ONLY the documented Customer Portal endpoints. No other APIs.
All methods return structured dicts:
- {"status": "success", "data": ...} for 2xx responses
- {"error": "...", "message": "..."} for non-2xx responses
"""

from __future__ import annotations

import logging
from typing import Any

import httpx

from app.core.config import get_settings

logger = logging.getLogger("wasla.crm")

_client: httpx.AsyncClient | None = None


def _require_client() -> httpx.AsyncClient:
    if _client is None:
        raise RuntimeError("CRM client not initialized. Call init_crm_client() first.")
    return _client


async def init_crm_client() -> None:
    global _client
    if _client is not None:
        return
    settings = get_settings()
    _client = httpx.AsyncClient(
        base_url=settings.crm_api_base_url,
        timeout=settings.crm_api_timeout_seconds,
        headers={"Content-Type": "application/json"},
    )


async def close_crm_client() -> None:
    global _client
    if _client is None:
        return
    await _client.aclose()
    _client = None


def _auth_headers(bearer_token: str | None) -> dict[str, str]:
    if not bearer_token:
        return {}
    return {"Authorization": f"Bearer {bearer_token}"}


def _error_from_status(status_code: int, message: str | None = None) -> dict[str, str]:
    if status_code == 400:
        error = "bad_request"
    elif status_code == 401:
        error = "unauthorized"
    elif status_code == 404:
        error = "not_found"
    elif status_code == 409:
        error = "conflict"
    elif status_code == 422:
        error = "unprocessable"
    else:
        error = "service_error"
    return {"error": error, "message": message or "CRM API request failed."}


async def _request(
    method: str,
    path: str,
    *,
    bearer_token: str | None = None,
    params: dict[str, Any] | None = None,
    json_body: dict[str, Any] | None = None,
) -> dict[str, Any]:
    client = _require_client()
    headers = _auth_headers(bearer_token)
    logger.info(
        "CRM request",
        extra={"method": method, "path": path, "params": params},
    )
    try:
        response = await client.request(
            method,
            path,
            params=params,
            json=json_body,
            headers=headers,
        )
    except httpx.RequestError as exc:
        logger.exception("CRM request failed: %s", exc)
        return {"error": "service_error", "message": "CRM API is unavailable."}

    if 200 <= response.status_code < 300:
        if response.status_code == 204:
            return {"status": "success", "data": None}
        try:
            payload = response.json()
        except ValueError:
            payload = {"raw": response.text}
        return {"status": "success", "data": payload}

    try:
        error_payload = response.json()
        message = error_payload.get("message") or error_payload.get("error")
    except ValueError:
        message = response.text
    return _error_from_status(response.status_code, message=message)


# ── Public endpoints ──────────────────────────────────────────────

async def list_companies(
    *,
    page_index: int | None = None,
    page_size: int | None = None,
    search: str | None = None,
    service_type: str | None = None,
    sort_by: str | None = None,
) -> dict[str, Any]:
    params = {
        "pageIndex": page_index,
        "pageSize": page_size,
        "search": search,
        "serviceType": service_type,
        "sortBy": sort_by,
    }
    return await _request("GET", "/companies", params={k: v for k, v in params.items() if v is not None})


async def get_recommended_companies(
    *,
    page_index: int | None = None,
    page_size: int | None = None,
    service_type: str | None = None,
) -> dict[str, Any]:
    params = {
        "pageIndex": page_index,
        "pageSize": page_size,
        "serviceType": service_type,
    }
    return await _request("GET", "/recommended-companies", params={k: v for k, v in params.items() if v is not None})


async def get_trending_companies(
    *,
    page_index: int | None = None,
    page_size: int | None = None,
    service_type: str | None = None,
) -> dict[str, Any]:
    params = {
        "pageIndex": page_index,
        "pageSize": page_size,
        "serviceType": service_type,
    }
    return await _request("GET", "/trending-companies", params={k: v for k, v in params.items() if v is not None})


async def get_company_profile(company_id: int) -> dict[str, Any]:
    return await _request("GET", f"/companies/{company_id}")


async def get_company_reviews(
    company_id: int,
    *,
    page_index: int | None = None,
    page_size: int | None = None,
    sort_by: str | None = None,
) -> dict[str, Any]:
    params = {
        "pageIndex": page_index,
        "pageSize": page_size,
        "sortBy": sort_by,
    }
    return await _request("GET", f"/companies/{company_id}/reviews", params={k: v for k, v in params.items() if v is not None})


# ── Reviews ───────────────────────────────────────────────────────

async def submit_review(
    bearer_token: str,
    company_id: int,
    *,
    rating: int,
    review_text: str | None = None,
) -> dict[str, Any]:
    payload = {"rating": rating, "reviewText": review_text}
    return await _request("POST", f"/companies/{company_id}/reviews", bearer_token=bearer_token, json_body=payload)


async def update_review(
    bearer_token: str,
    company_id: int,
    *,
    rating: int | None = None,
    review_text: str | None = None,
) -> dict[str, Any]:
    payload = {"rating": rating, "reviewText": review_text}
    payload = {k: v for k, v in payload.items() if v is not None}
    return await _request("PUT", f"/companies/{company_id}/reviews", bearer_token=bearer_token, json_body=payload)


async def delete_review(bearer_token: str, company_id: int) -> dict[str, Any]:
    return await _request("DELETE", f"/companies/{company_id}/reviews", bearer_token=bearer_token)


async def get_my_reviews(
    bearer_token: str,
    *,
    page_index: int | None = None,
    page_size: int | None = None,
) -> dict[str, Any]:
    params = {"pageIndex": page_index, "pageSize": page_size}
    return await _request("GET", "/my/reviews", bearer_token=bearer_token, params={k: v for k, v in params.items() if v is not None})


# ── Profiles ──────────────────────────────────────────────────────

async def get_my_profile(bearer_token: str) -> dict[str, Any]:
    return await _request("GET", "/my/profile", bearer_token=bearer_token)


async def update_my_profile(
    bearer_token: str,
    payload: dict[str, Any],
) -> dict[str, Any]:
    return await _request("PUT", "/my/profile", bearer_token=bearer_token, json_body=payload)


async def get_my_lead_profile(bearer_token: str) -> dict[str, Any]:
    return await _request("GET", "/my/lead-profile", bearer_token=bearer_token)


async def update_my_lead_profile(
    bearer_token: str,
    payload: dict[str, Any],
) -> dict[str, Any]:
    return await _request("PUT", "/my/lead-profile", bearer_token=bearer_token, json_body=payload)


# ── Offers ────────────────────────────────────────────────────────

async def get_my_offers(
    bearer_token: str,
    *,
    page_index: int | None = None,
    page_size: int | None = None,
    status: str | None = None,
) -> dict[str, Any]:
    params = {"pageIndex": page_index, "pageSize": page_size, "status": status}
    return await _request("GET", "/my/offers", bearer_token=bearer_token, params={k: v for k, v in params.items() if v is not None})


async def get_offer_details(bearer_token: str, offer_id: int) -> dict[str, Any]:
    return await _request("GET", f"/my/offers/{offer_id}", bearer_token=bearer_token)


async def accept_offer(
    bearer_token: str,
    offer_id: int,
    *,
    digital_signature: str,
    payment_method: int,
) -> dict[str, Any]:
    payload = {"digitalSignature": digital_signature, "paymentMethod": payment_method}
    return await _request("POST", f"/my/offers/{offer_id}/accept", bearer_token=bearer_token, json_body=payload)


async def reject_offer(
    bearer_token: str,
    offer_id: int,
    *,
    rejection_reason: str,
) -> dict[str, Any]:
    payload = {"rejectionReason": rejection_reason}
    return await _request("POST", f"/my/offers/{offer_id}/reject", bearer_token=bearer_token, json_body=payload)


# ── Service requests ──────────────────────────────────────────────

async def submit_service_request(
    bearer_token: str,
    *,
    company_id: int,
    preferred_date: str | None = None,
    origin_address: str | None = None,
    destination_address: str | None = None,
    notes: str | None = None,
) -> dict[str, Any]:
    payload = {
        "companyId": company_id,
        "preferredDate": preferred_date,
        "originAddress": origin_address,
        "destinationAddress": destination_address,
        "notes": notes,
    }
    payload = {k: v for k, v in payload.items() if v is not None}
    return await _request("POST", "/service-requests", bearer_token=bearer_token, json_body=payload)


async def get_my_service_requests(
    bearer_token: str,
    *,
    page_index: int | None = None,
    page_size: int | None = None,
    status: str | None = None,
) -> dict[str, Any]:
    params = {"pageIndex": page_index, "pageSize": page_size, "status": status}
    return await _request("GET", "/my/service-requests", bearer_token=bearer_token, params={k: v for k, v in params.items() if v is not None})


async def get_service_request_details(bearer_token: str, request_id: int) -> dict[str, Any]:
    return await _request("GET", f"/my/service-requests/{request_id}", bearer_token=bearer_token)


# ── Dashboard ─────────────────────────────────────────────────────

async def get_my_dashboard(bearer_token: str) -> dict[str, Any]:
    return await _request("GET", "/my/dashboard", bearer_token=bearer_token)


# ── Digital Signature ─────────────────────────────────────────────

async def get_digital_signature(bearer_token: str, *, password: str) -> dict[str, Any]:
    """
    Retrieve the lead's Digital Signature after password verification.
    Used to sign offers. Brute-force protection: 5 failed attempts trigger 15-min lockout.
    """
    payload = {"password": password}
    return await _request("POST", "/my/digital-signature", bearer_token=bearer_token, json_body=payload)
